const _englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
const _banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

/// Converts English digits in [input] to Bangla digits.
/// e.g. "50" → "৫০"
String toBanglaDigits(String input) {
  var result = input;
  for (var i = 0; i < _englishDigits.length; i++) {
    result = result.replaceAll(_englishDigits[i], _banglaDigits[i]);
  }
  return result;
}

/// Formats a price as a Bangla numeral string.
/// Whole numbers drop the decimal: 30.0 → ৩০, fractions keep one place: 30.5 → ৩০.৫
String formatPriceBangla(num price) {
  final s = (price == price.roundToDouble())
      ? price.toInt().toString()
      : price.toStringAsFixed(1);
  return toBanglaDigits(s);
}
